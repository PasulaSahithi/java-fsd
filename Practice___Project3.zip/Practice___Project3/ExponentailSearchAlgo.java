package Practice___Project3;

public class ExponentailSearchAlgo 
{
    public static int exponentialSearch(int arr[], int target) {
        int length = arr.length;

        if (arr[0] == target)
            return 0;

        int i = 1;
        while (i < length && arr[i] <= target) {
            i *= 2;
        }

        return binarySearch(arr, target, i / 2, Math.min(i, length - 1));
    }

    public static int binarySearch(int arr[], int target, int low, int high) {
        if (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target)
                return mid;
            if (arr[mid] > target)
                return binarySearch(arr, target, low, mid - 1);
            return binarySearch(arr, target, mid + 1, high);
        }
        return -1;
    }

    public static void main(String[] args) {
        int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int target = 6;
        int result = exponentialSearch(arr, target);

        if (result == -1) {
            System.out.println("Element not found");
        } else {
            System.out.println("Element found at index " + result);
        }
    }
}
