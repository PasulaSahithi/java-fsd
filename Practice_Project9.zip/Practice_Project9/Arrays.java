package Question9;

public class Arrays 
{
	public static void main(String[] args) 
	{
		//Declaring and initialing an array of integers
		int numbers[]= {10,20,30,40,50,60,70,80,90,100};

		//Accessing and printing elements from an array
		System.out.println("The numbers are: ");
		for(int i=0;i<numbers.length;i++)
		{
			System.out.print(numbers[i]+" ");
		}
		System.out.println();
		
		//Declaring and initialing an array of String
		String names[]= {"java","python","c++","c",".net"};

		//Accessing and printing elements from an array
		System.out.println("The names are: ");
		for(int i=0;i<names.length;i++)
		{
			System.out.print(names[i]+" ");
		}
		System.out.println();
		
		//To find length of the arrays
		System.out.println("The length of integer array is: "+numbers.length);
		System.out.println("The length of string array is: "+names.length);
	}
}
