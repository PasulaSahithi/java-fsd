package Question10;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionsDemo 
{
	public static void main(String[] args) 
	{
		String name="This is an example for regular expressions";
		String regExp="\\b\\w*regular\\w*\\b";
		Pattern pattern= Pattern.compile(regExp);
		Matcher matcher=pattern.matcher(name);
		System.out.println("Words in the text containing examples: ");
		while(matcher.find())
		{
			System.out.println(matcher.group());
		}
		boolean matchesText=matcher.matches();
		System.out.println("Entire text matches: "+matchesText);


	}
}
