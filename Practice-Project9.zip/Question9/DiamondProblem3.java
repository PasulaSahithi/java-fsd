package Question9;

public interface DiamondProblem3 
{
void mul();
void div();
}
