package Question9;

public class Main 
{
public static void main(String[] args) 
{
	DiamondProblem2 ref=new DiamondProblem2();
	ref.add();
	ref.sub();
	ref.mul();
	ref.div();
}

	
}
