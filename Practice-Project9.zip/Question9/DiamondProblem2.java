package Question9;

public class DiamondProblem2 implements  DiamondProblem,DiamondProblem3
{

	@Override
	public void add() {
		System.out.println("This method for addition");
		
	}

	@Override
	public void sub() {
		
		System.out.println("This method for subtraction");
	}

	@Override
	public void mul() {
		System.out.println("This method for multiplication");
		
	}

	@Override
	public void div() {
	System.out.println("This method for division");
		
	}

}
