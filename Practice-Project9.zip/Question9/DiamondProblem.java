package Question9;

public interface DiamondProblem 
{	
void add();
void sub();
}
