package Question5;

public class Node 
{
	 int data;
	    Node next;
	    Node(int data) 
	    {
	        this.data = data;
	        this.next = null;
	    }
	    public static void main(String[] args) {
	        LinkedList list = new LinkedList();

	        list.append(1);
	        list.append(2);
	        list.append(3);
	        list.append(4);
	        list.append(5);

	        System.out.println("Original linked list:");
	        list.display();

	        int key = 3;
	        list.deleteKey(key);

	        System.out.println("Linked list after deleting the first occurrence of " + key + ":");
	        list.display();
	    }
	}

	class LinkedList {
	    Node head;

	    void deleteKey(int key) {
	        Node current = head;
	        Node prev = null;

	        if (current != null && current.data == key) {
	            head = current.next;
	            return;
	        }

	        while (current != null && current.data != key) {
	            prev = current;
	            current = current.next;
	        }

	        if (current == null) {
	            System.out.println("Key not found in the linked list.");
	            return;
	        }

	        prev.next = current.next;
	    }

	    void append(int data) {
	        Node newNode = new Node(data);

	        if (head == null) {
	            head = newNode;
	            return;
	        }

	        Node last = head;
	        while (last.next != null) {
	            last = last.next;
	        }

	        last.next = newNode;
	    }

	    void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }
}


