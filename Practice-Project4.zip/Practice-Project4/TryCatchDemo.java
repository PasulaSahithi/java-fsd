package Question4;

public class TryCatchDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("This is an example of try and catch block");
		try
		{
			System.out.println("This is try block");
			int a=50/0;
		}
		catch(Exception e)
		{
			System.out.println("This is catch block");
		}
		finally
		{
			System.out.println("Finally block will execute at any situation");
		}
	}
}
