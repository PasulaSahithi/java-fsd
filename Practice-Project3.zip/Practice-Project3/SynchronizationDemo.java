	package Question3;
	
	class Counter {
		private int count = 0;
	
		// Synchronized method to increment the counter
		public synchronized void increment() {
			count++;
		}
	
		// Synchronized method to decrement the counter
		public synchronized void decrement() {
			count--;
		}
	
		public int getCount() {
			return count;
		}
	}
	
	public class SynchronizationDemo {
		public static void main(String[] args) {
			Counter counter = new Counter();
	
			// Create multiple threads to increment and decrement the counter
			Thread incrementThread = new Thread(() -> {
				for (int i = 0; i < 10000; i++) {
					counter.increment();
				}
			});
	
			Thread decrementThread = new Thread(() -> {
				for (int i = 0; i < 10000; i++) {
					counter.decrement();
				}
			});
	
			incrementThread.start();
			decrementThread.start();
	
			try {
				incrementThread.join();
				decrementThread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	
			// Display the final count
			System.out.println("Final Count: " + counter.getCount());
		}
	}
	
