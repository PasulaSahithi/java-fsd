package Question4;

public class Box 
{
	double length;
	double breadth;
	double height;

	//Parameterized Constructor
	Box(double length,double breadth,double height)
	{
		double volume=length*breadth*height;
		System.out.println("The volume of the box is: "+volume);
	}
	
	//Default constructor
	Box()
	{
		double length=100;
		double breadth=200;
		double height=300;
		double volume=length*breadth*height;
		System.out.println("The volume of the box is: "+volume);
	}
}
