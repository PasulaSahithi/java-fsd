package Question4;

public class BoxMain 
{
	public static void main(String[] args) 
	{
		//Invoking parameterized constructor
		Box box1=new Box(10,20,30);
		
		//Invoking default constructor
		Box box2=new Box();

	}
}