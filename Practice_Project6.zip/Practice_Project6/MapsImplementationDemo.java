package Question6;
import java.util.HashMap;
import java.util.Map;
public class MapsImplementationDemo 
{
		public static void main(String[] args) {
		

		//Create hashmap for employeeName and salary
		Map<String, Double> mapRef=new HashMap<>();

		mapRef.put("Sahithi",19000.0);
		mapRef.put("Bharath",18500.0);
		mapRef.put("Anu",19500.0);

		System.out.println("====================");

		//Retrieve values by key
		double salarySahithi=mapRef.get("Sahithi");

		System.out.println("Salary of Sahithi is: "+salarySahithi);

		System.out.println("======================");

		//check key exists in Map

		boolean keyInMap=mapRef.containsKey("java");
		System.out.println("Key Contains 'java': "+keyInMap);

		//remove a pair using key

		mapRef.remove("Sahithi");


		System.out.println("============================");

		//access keys of map
		System.out.println("keys of employee Hashmap : "+mapRef.keySet());

		System.out.println("==============================");

		//access values of map
		System.out.println("values of employee Hashmap : "+mapRef.values());



		System.out.println("==========================");

		// Iterate over the map and display all key-value pairs
		System.out.println("All key-value pairs:");
		for (Map.Entry<String, Double> entry : mapRef.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}

		System.out.println("===========================");

		int expectedLength=3;

		int actualSize=mapRef.size();

		assert actualSize==expectedLength:"Map size is incorrect";


	}

}
