package Question6;

public class Main 
{
	public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        list.insert(5);
        list.insert(2);
        list.insert(8);
        list.insert(1);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
    }
}

class SortedCircularLinkedList {
    private Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (data < head.data) {
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}