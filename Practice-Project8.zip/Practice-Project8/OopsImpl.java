package Question8;


//inheritence
public class OopsImpl extends OopsDemo
{
	@Override
	public void add(int num1, int num2) {
		System.out.println("The addition of two number is: "+(num1+num2));
	}
	
	@Override
	public void sub(int num1, int num2) {
		System.out.println("The substrcation of two numbers is: "+(num1-num2));
	}

}
