package Question8;

public class Main 
{
public static void main(String[] args) 
{
	OopsImpl ref=new OopsImpl();
	ref.setGpin(1234);
	ref.setUpin(4321);
	//example for encapsulation
	System.out.println("Getting the setted Gpin: "+ref.getGpin());
	System.out.println("Getting the setted Upin: "+ref.getUpin());
	ref.add(10, 20);
	ref.sub(30, 20);
}
}
