package Question8;

public abstract class OopsDemo 
{
private int gpin;
private int upin;
//example for abstraction
public abstract void add(int num1,int num2);
public abstract void sub(int num1,int num2);

//example for encapsulation
public int getGpin() {
	return gpin;
}
public void setGpin(int gpin) {
	this.gpin = gpin;
}
public int getUpin() {
	return upin;
}
public void setUpin(int upin) {
	this.upin = upin;
}

}
