package Question1;

public class ThreadMain
{
public static void main(String[] args) 
{
	ThreadEx t1=new ThreadEx();
	t1.start();
	
}
}
