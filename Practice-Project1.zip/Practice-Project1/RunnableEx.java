package Question1;

public class RunnableEx implements Runnable
{

	@Override
	public void run() {
		System.out.println("This is an example of the thread by implementing Runnable interface");
		try
		{
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			
		}
	}
	


}
