package Question1;

public class ThreadEx extends Thread
{
public void run()
{
	System.out.println("This is an example of thread by extending thread class");
	try
	{
		Thread.sleep(2000);
	}
	catch(Exception e)
	{
		
	}
}
}
