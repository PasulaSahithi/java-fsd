package Question1;

public class RunnableMain 
{
	public static void main(String[] args) 
	{
		RunnableEx runnable=new RunnableEx();
		Thread t1=new Thread(runnable);
		t1.start();
	}
}
