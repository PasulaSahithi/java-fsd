package Practice___Project1;

public class LinearSearch {

}
