package Question2;

public class SleepWaitEx 
{
	public static void main(String[] args) {
		final Object lock = new Object();

		// Thread 1: Sleep
		Thread thread1 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Thread 1: Going to sleep for 3 seconds.");
				try {
					Thread.sleep(3000); // Sleep for 3 seconds
				} catch (InterruptedException e) {
					System.out.println(e);
				}
				System.out.println("Thread 1: Woke up after sleep.");
			}
		});

		// Thread 2: Wait
		Thread thread2 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Thread 2: Waiting...");
				try {
					lock.wait(); // Wait until notified
				} catch (InterruptedException e) {
					System.out.println(e);
				}
				System.out.println("Thread 2: Resumed after wait.");
			}
		});

		thread1.start();
		thread2.start();

		// Sleep for a moment to ensure thread2 starts waiting
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		// Notify thread2 to resume
		synchronized (lock) {
			lock.notify();
		}
	}
}
