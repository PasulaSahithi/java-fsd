package Question1;

public class TypeCasting 
{
	public static void main(String[] args) 
	{
		//Implicit type-casting
		int number1=10;
		double number2=number1;
		System.out.println(number1);
		System.out.println(number2);
		
		////explicit type-casting
		int number3=20;
		short number4=(short)number3;
		System.out.println(number3);
		System.out.println(number4);
		
		
	}
}
