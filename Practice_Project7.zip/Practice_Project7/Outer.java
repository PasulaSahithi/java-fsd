package Question7;

public class Outer 
{
	int outdata=1200;
	
	//non-static Inner class
	class Inner
	{
		void showInner()
		{
			System.out.println("InnerClass: "+outdata);
		}
	}
	
	//Static inner class
	static class StaticInner
	{
		void showstaticInner()
		{
			System.out.println("StaticInner: "+new Outer().outdata);
		}
	}
	public static void main(String[] args) 
	{
		Outer out_class=new Outer();
		
		//creating object for inner class
		Inner inner=out_class.new Inner();
		inner.showInner();
		
		//creating object for static inner class
		StaticInner staticInner=new StaticInner();
		staticInner.showstaticInner();
		
	}
}
