package Question5;

public class FinallyDemo 
{
	public static void main(String[] args) 
	{
	System.out.println("This is an example for exception handling using try and catch...!");
	try
	{
		int a=10/0;
	}
	catch(Exception e)
	{
		System.out.println("Catch block: "+e.getMessage());;
	}
	finally {
		System.out.println("Finally block");
	}
	}
}
