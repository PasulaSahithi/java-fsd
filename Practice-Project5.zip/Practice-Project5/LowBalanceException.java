package Question5;

public class LowBalanceException extends Exception
{

	@Override
	public String toString() {
		return "You do not have a sufficient balance to withdraw";
	}

}
