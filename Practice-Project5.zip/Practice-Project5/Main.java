package Question5;

public class Main 
{
public static void main(String[] args) throws LowBalanceException 
{
	ATM ref=new ATM();
	ref.withdraw(1000);
	
	
}
}
