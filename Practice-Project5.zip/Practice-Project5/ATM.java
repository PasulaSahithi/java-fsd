package Question5;

import java.util.Scanner;
public class ATM 
{
int account=1000000;
public void withdraw(int amount) throws LowBalanceException 
{
	if(amount<=100000)
	{
		int finalAmount=account-amount;
		System.out.println("The final amount is:  "+finalAmount);
	}
	else
	{
		throw new LowBalanceException();
	}
	
}
}
