package Question2;

public class PublicAcessModifier
{
	public String public_var="This is example for public variable";
	public void public_method()
	{
		System.out.println("This is example for public method");
	}

}
