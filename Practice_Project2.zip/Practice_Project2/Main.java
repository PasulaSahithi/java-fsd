package Question2;

public class Main
{
	public static void main(String[] args) 
	{
		//Accessing private members
		PrivateAccessModifier privateObj=new PrivateAccessModifier();
		privateObj.privateAccessMethod();

		//Accessing public members
		PublicAcessModifier publicObj=new PublicAcessModifier();
		System.out.println(publicObj.public_var);
		publicObj.public_method();

		//Accessing protected members
		ProtectedAccessModifier protectedObj=new ProtectedAccessModifier();
		System.out.println(protectedObj.protectedVariable);
		protectedObj.protectedMethod();

		//Accessing default members
		DefaultAccessModifier defaultObj=new DefaultAccessModifier();
		System.out.println(defaultObj.defaultVariable);
		defaultObj.defaultMethod();

	}
}	
