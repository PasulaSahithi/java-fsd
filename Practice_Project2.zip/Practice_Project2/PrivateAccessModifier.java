package Question2;

public class PrivateAccessModifier
{
	private String private_var="This is an example for private varibale";
	private void private_Method()
	{
		System.out.println("This is an example for private methods");
	}

	public void privateAccessMethod()
	{
		System.out.println(private_var);
		private_Method();
	}
}
