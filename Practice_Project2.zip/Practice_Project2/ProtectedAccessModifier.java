package Question2;

public class ProtectedAccessModifier 
{
	protected String protectedVariable="This is example for protected variable";
	protected void protectedMethod()
	{
		System.out.println("This is an example for protected method");
	}

}
