package Question2;

public class DefaultAccessModifier 
{
 String defaultVariable="This is an example for default varibale";
 void defaultMethod()
 {
	 System.out.println("This is an example for default method");
 }
}
