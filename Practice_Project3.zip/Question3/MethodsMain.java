package Question3;

public class MethodsMain 
{
public static void main(String[] args) 
{
	Methods methods=new Methods();
	
	//Calling method without return without arguments
	methods.empId=101;
	methods.empName="Sahithi";
	methods.empSalary=100000;
	methods.empMethodOne();
	
	//Calling method with return without arguments
	double increment=methods.incSalary();
	System.out.println("The incremented salary is: "+increment);
	
	//Calling method with return-type with arguments
	System.out.println("The Salary including performance bonus is: "+methods.performanceBonus(25000));
	
	//Calling method without return-type with arguments
	methods.salDecrement(2000);
	


}
}
