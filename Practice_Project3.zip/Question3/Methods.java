package Question3;

public class Methods 
{
	int empId;
	String empName;
	double empSalary;

	//Method without return-type without arguments
	public void empMethodOne()
	{
		System.out.println("Employee id is: "+empId);
		System.out.println("Employee name is: "+empName);
		System.out.println("Employee salary is: "+empSalary);
	}

	//Method with return-type without arguments
	public double incSalary()
	{
		double bonus=1000;
		return empSalary+bonus;
	}
	
	//Method with return-type with arguments
	public double performanceBonus(double performance)
	{
		return empSalary+performance;
	}
	
	//Method without return-type with arguments
	public void salDecrement(double decrement)
	{
		System.out.println("The salary after decrementation is: "+decrement);
	}

}

