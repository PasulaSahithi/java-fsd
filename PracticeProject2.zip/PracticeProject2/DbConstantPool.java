package PracticeProject2;

public class DbConstantPool 
{
public static final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
public static final String DRIVER_URL = "jdbc:mysql://localhost:3306/databaseone";
public static final String USERNAME="root";
public static final String PASSWORD="root";
}
