package Question8;

public class StringDemo 
{
	public static void main(String[] args) {
		//Creating a string
		String demo="StringDemo";

		//Converting string to stringBuffer
		StringBuffer buffer=new StringBuffer(demo);
		buffer.append("StringBufferDemo");
		System.out.println("Using StringBuffer: "+buffer);

		//Converting string to string to stringBuilder
		StringBuilder builder=new StringBuilder(demo);
		builder.append("StringBuilderDemo");
		System.out.println("Using StringBuilder: "+builder);

		//Original String
		System.out.println("Original String: "+demo);

	}
}
